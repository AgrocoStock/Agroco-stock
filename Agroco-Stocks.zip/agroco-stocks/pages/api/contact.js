
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.status(405).json({ error: 'Method not allowed' })
    return
  }

  // Simple serverless stub: in production, replace with
  // an email provider (SendGrid, SMTP), Zapier webhook, or database write.
  // Here we just echo back the fields (Vercel will run this serverless).
  const name = req.body.get ? req.body.get('name') : ''
  const email = req.body.get ? req.body.get('email') : ''
  const message = req.body.get ? req.body.get('message') : ''

  console.log('Contact form received:', { name, email, message })

  // Ideally: send email to your chosen address or store in DB.
  res.status(200).json({ ok: true })
}
